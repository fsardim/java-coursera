
public class CompraParcelada extends Compra {

	protected double percJuros;
	protected int qtdParcelas;
	
	public CompraParcelada(double valor, int parcelas, double juros) {
		super(valor);
		this.qtdParcelas = parcelas;
		this.percJuros = juros;
	}
	
	protected double total(){

		double juros = 1;
		
		for (int i=0;i<qtdParcelas;i++){
			juros *= (1+percJuros);
		}
		
		return juros*valorCompra;
		
	}

}
