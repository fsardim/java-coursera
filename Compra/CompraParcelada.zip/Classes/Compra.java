
public class Compra {
	
	protected double valorCompra;
	
	public Compra(double valor){
		valorCompra = valor;
	}
	
	protected double total(){
		return valorCompra;
	}

}
