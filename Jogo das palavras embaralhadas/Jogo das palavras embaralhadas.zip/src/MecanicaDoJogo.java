
public interface MecanicaDoJogo {
	public String getNomeMecanica();
	public int getPontuacao();
	public int getTentativas();
	public void computarAcerto();
	public void computarErro();
}
