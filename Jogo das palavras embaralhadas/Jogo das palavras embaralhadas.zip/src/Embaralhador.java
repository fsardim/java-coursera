
public interface Embaralhador {
	public String EmbaralharPalavra();
}
