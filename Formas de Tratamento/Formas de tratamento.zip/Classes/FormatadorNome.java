
public interface FormatadorNome {

	public String formatarNome(String nome, String sobrenome);
	//public String nomeInformal();
	//public String nomeRespeitoso(String sexo);
	//public String ComTitulo(String titulo);
	
}